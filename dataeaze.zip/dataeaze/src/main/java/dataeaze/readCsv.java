package dataeaze;

import java.io.File;
import java.util.Scanner;

public class readCsv {
	public static void main(String[] args) throws Exception  
	{  
		 
		Scanner sc = new Scanner(new File("/home/lenovo/Downloads/startup.csv"));  
		sc.useDelimiter(",");     
		while (sc.hasNext())  
		{  
			System.out.print(sc.next());  
		}   
		sc.close();   
	}  
}
